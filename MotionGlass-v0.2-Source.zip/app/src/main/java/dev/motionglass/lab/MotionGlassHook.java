package dev.motionglass.lab;

import android.view.animation.AccelerateDecelerateInterpolator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.LinearInterpolator;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * One UI MotionGlass Lab v0.2.
 * Fail-open experimental launcher process hooks; no SystemUI or boot hooks.
 * - limited spring-like easing for launcher app transition ValueAnimators
 * - slight boost of existing round corners for launcher remote transitions
 * - multi-sampled bitmap ghosting on launch icon taps (visual approximation only)
 * NOT a genuine compositor-level directional motion blur implementation.
 */
public final class MotionGlassHook implements IXposedHookLoadPackage {
    private static final String LAUNCHER = "com.sec.android.app.launcher";
    private static final String TAG = "MotionGlass v0.2: ";
    private static final float TIME_FACTOR = 1.06f;
    private static final float CORNER_FACTOR = 1.13f;
    private static final AtomicInteger LOG_BUDGET = new AtomicInteger(18);

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!LAUNCHER.equals(lpparam.packageName) || !LAUNCHER.equals(lpparam.processName)) {
            return;
        }
        log("loaded in One UI Home; testing hooks");
        probe(lpparam.classLoader, "com.android.launcher3.QuickstepTransitionManager");
        probe(lpparam.classLoader, "com.android.launcher3.QuickstepAppTransitionManagerImpl");
        probe(lpparam.classLoader, "com.android.launcher3.BubbleTextView");
        probe(lpparam.classLoader, "com.android.quickstep.AbsSwipeUpHandler");
        hookIconTaps();
        hookTransitionTiming();
        hookRoundedSurfaces();
    }

    private static void hookIconTaps() {
        try {
            Set<XC_MethodHook.Unhook> hooks = XposedBridge.hookAllMethods(
                    View.class, "performClick", new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                if (!(param.thisObject instanceof View)) return;
                                View view = (View) param.thisObject;
                                // Only icon-like views, not controls, dialogs or settings.
                                if (!isAppIcon(view)) return;
                                IconTrail.play(view);
                            } catch (Throwable t) {
                                logOnce("icon trail skipped: " + t.getClass().getSimpleName());
                            }
                        }
                    });
            log("icon click hooks=" + hooks.size());
        } catch (Throwable t) {
            log("icon trail unavailable: " + t.getClass().getSimpleName());
        }
    }

    private static boolean isAppIcon(View view) {
        if (!view.isShown() || view.getWidth() < 30 || view.getHeight() < 30) return false;
        String cls = view.getClass().getName().toLowerCase(Locale.ROOT);
        // Samsung can rename icon view classes. Keep this strict until APK analysis.
        return cls.contains("bubbletextview") || cls.contains("appiconview")
                || cls.contains("appiconbutton") || cls.contains("iconview");
    }

    private static void hookTransitionTiming() {
        try {
            Set<XC_MethodHook.Unhook> hooks = XposedBridge.hookAllMethods(
                    ValueAnimator.class, "setDuration", new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                if (param.args == null || param.args.length != 1
                                        || !(param.args[0] instanceof Long)) return;
                                long millis = (Long) param.args[0];
                                if (millis < 170L || millis > 550L || !inLauncherTransition()) return;
                                param.args[0] = Math.min(600L, Math.round(millis * TIME_FACTOR));
                                logOnce("transition duration " + millis + " -> " + param.args[0]);
                            } catch (Throwable t) {
                                logOnce("timing skipped: " + t.getClass().getSimpleName());
                            }
                        }
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                if (!(param.thisObject instanceof ValueAnimator)) return;
                                ValueAnimator animator = (ValueAnimator) param.thisObject;
                                if (animator.getDuration() < 170L || animator.getDuration() > 600L) return;
                                if (!inLauncherTransition()) return;
                                TimeInterpolator existing = animator.getInterpolator();
                                // Avoid breaking Samsung's complex custom curve/gesture drivers.
                                if (existing == null || existing instanceof LinearInterpolator
                                        || existing instanceof AccelerateDecelerateInterpolator) {
                                    animator.setInterpolator(SpringEase.INSTANCE);
                                    logOnce("spring-like transition easing assigned");
                                }
                            } catch (Throwable t) {
                                logOnce("easing skipped: " + t.getClass().getSimpleName());
                            }
                        }
                    });
            log("transition timing hooks=" + hooks.size());
        } catch (Throwable t) {
            log("timing hook unavailable: " + t.getClass().getSimpleName());
        }
    }

    private static void hookRoundedSurfaces() {
        try {
            // SurfaceControl.Transaction is a hidden API; name-based hook avoids
            // statically depending on non-public classes in the Android SDK.
            Class<?> tx = Class.forName("android.view.SurfaceControl$Transaction");
            Set<XC_MethodHook.Unhook> hooks = XposedBridge.hookAllMethods(
                    tx, "setCornerRadius", new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                if (param.args == null || param.args.length != 2
                                        || !(param.args[1] instanceof Float)) return;
                                float r = (Float) param.args[1];
                                // Never set radius on a surface that Samsung intended square.
                                if (r <= 1f || r >= 150f || !inLauncherTransition()) return;
                                param.args[1] = Math.min(155f, r * CORNER_FACTOR);
                                logOnce("existing transition corner radii enhanced");
                            } catch (Throwable t) {
                                logOnce("rounding skipped: " + t.getClass().getSimpleName());
                            }
                        }
                    });
            log("surface roundness hooks=" + hooks.size());
        } catch (Throwable t) {
            log("surface roundness unavailable: " + t.getClass().getSimpleName());
        }
    }

    private static boolean inLauncherTransition() {
        StackTraceElement[] frames = Thread.currentThread().getStackTrace();
        int limit = Math.min(35, frames.length);
        for (int i = 3; i < limit; i++) {
            String n = frames[i].getClassName().toLowerCase(Locale.ROOT);
            if (n.contains("quickstep") || n.contains("apptransition")
                    || n.contains("launcheranimation") || n.contains("swipeuphandler")
                    || n.contains("remoteanimation") || n.contains("transitionmanager")
                    || n.contains("recentsanimation")) {
                return true;
            }
        }
        return false;
    }

    private static void probe(ClassLoader loader, String name) {
        try {
            Class.forName(name, false, loader);
            log("FOUND " + name);
        } catch (ClassNotFoundException ignored) {
            log("not found " + name);
        } catch (Throwable t) {
            log("probe failed " + name + ": " + t.getClass().getSimpleName());
        }
    }

    static void logOnce(String line) {
        if (LOG_BUDGET.getAndDecrement() > 0) log(line);
    }

    private static void log(String line) {
        try { XposedBridge.log(TAG + line); } catch (Throwable ignored) { }
    }
}
