package dev.motionglass.lab;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewOverlay;

/**
 * A lightweight temporal multi-sample ghost effect on launcher icon taps.
 * The previous positions are composited as translucent samples to mimic
 * a motion trail. This is NOT directional blur of the actual app window.
 */
public final class IconTrail {
    private static long lastTapUptime;
    private static final int DURATION_MS = 310;
    private IconTrail() { }

    public static void play(View icon) {
        // Called from View.performClick on the main/UI thread.
        long now = SystemClock.uptimeMillis();
        if (now - lastTapUptime < 240L) return;
        lastTapUptime = now;

        View root = icon.getRootView();
        if (root == null || !root.isAttachedToWindow()
                || root.getWidth() <= 0 || root.getHeight() <= 0) return;

        final Bitmap picture = snapshot(icon);
        if (picture == null) return;
        final int[] iconLoc = new int[2];
        final int[] rootLoc = new int[2];
        icon.getLocationOnScreen(iconLoc);
        root.getLocationOnScreen(rootLoc);
        final float cx = iconLoc[0] - rootLoc[0] + icon.getWidth() / 2f;
        final float cy = iconLoc[1] - rootLoc[1] + icon.getHeight() / 2f;
        final float density = root.getResources().getDisplayMetrics().density;
        final TrailDrawable drawable = new TrailDrawable(picture, cx, cy, density,
                root.getWidth(), root.getHeight());
        drawable.setBounds(0, 0, root.getWidth(), root.getHeight());
        final ViewOverlay overlay = root.getOverlay();
        overlay.add(drawable);

        ValueAnimator movement = ValueAnimator.ofFloat(0f, 1f);
        movement.setDuration(DURATION_MS);
        movement.setInterpolator(SpringEase.INSTANCE);
        movement.addUpdateListener(a -> {
            drawable.progress = (Float) a.getAnimatedValue();
            drawable.invalidateSelf();
        });
        movement.addListener(new AnimatorListenerAdapter() {
            private boolean removed;
            private void cleanup() {
                if (removed) return;
                removed = true;
                try { overlay.remove(drawable); } catch (Throwable ignored) { }
                // Let the renderer and GC release the tiny bitmap safely.
            }
            @Override public void onAnimationCancel(Animator a) { cleanup(); }
            @Override public void onAnimationEnd(Animator a) { cleanup(); }
        });
        movement.start();
        MotionGlassHook.logOnce("icon motion trail started");
    }

    private static Bitmap snapshot(View icon) {
        try {
            int w = icon.getWidth();
            int h = icon.getHeight();
            if (w <= 0 || h <= 0) return null;
            float scale = Math.min(1f, 190f / Math.max(w, h));
            int targetW = Math.max(1, Math.round(w * scale));
            int targetH = Math.max(1, Math.round(h * scale));
            Bitmap result = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(result);
            canvas.scale((float) targetW / w, (float) targetH / h);
            icon.draw(canvas);
            return result;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static final class TrailDrawable extends Drawable {
        final Bitmap picture;
        final float cx, cy, density, rootW, rootH;
        final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        final Paint haloPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF rect = new RectF();
        float progress;
        int alpha = 255;

        TrailDrawable(Bitmap picture, float cx, float cy, float density, int rootW, int rootH) {
            this.picture = picture;
            this.cx = cx;
            this.cy = cy;
            this.density = density;
            this.rootW = rootW;
            this.rootH = rootH;
        }

        @Override public void draw(Canvas canvas) {
            if (picture.isRecycled()) return;
            float p = progress;
            float fade = (float) Math.pow(Math.max(0, 1 - p), 1.55);
            if (fade < 0.01f) return;
            float shiftX = (rootW / 2f - cx) * 0.25f;
            float shiftY = (rootH / 2f - cy) * 0.22f - 28f * density;

            // A gentle expanding rounded halo suggests icon->window morphology.
            float swell = 1f + 1.55f * p;
            float midX = cx + shiftX * p;
            float midY = cy + shiftY * p;
            float w = picture.getWidth() * swell;
            float h = picture.getHeight() * swell;
            rect.set(midX - w / 2f, midY - h / 2f,
                    midX + w / 2f, midY + h / 2f);
            haloPaint.setColor(Color.WHITE);
            haloPaint.setAlpha(Math.round(32f * fade * alpha / 255f));
            canvas.drawRoundRect(rect, Math.min(w,h)*0.27f,
                    Math.min(w,h)*0.27f, haloPaint);

            // Multiple past positions produce an actual multi-sample icon ghost trail.
            for (int i = 6; i >= 0; i--) {
                float t = Math.max(0f, p - i * 0.040f);
                float sampleScale = 1f + 0.18f * t;
                float x = cx + shiftX * t;
                float y = cy + shiftY * t;
                w = picture.getWidth() * sampleScale;
                h = picture.getHeight() * sampleScale;
                rect.set(x - w / 2f, y - h / 2f,
                        x + w / 2f, y + h / 2f);
                float weight = i == 0 ? 0.66f : 0.12f * (1f - i/8f);
                imagePaint.setAlpha(Math.round(255f * weight * fade * alpha / 255f));
                canvas.drawBitmap(picture, null, rect, imagePaint);
            }
        }
        @Override public void setAlpha(int value) { alpha = Math.max(0, Math.min(255, value)); invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter colorFilter) { imagePaint.setColorFilter(colorFilter); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
