package dev.motionglass.lab;

import android.animation.TimeInterpolator;

/**
 * Monotonic critically-damped, normalized spring response.
 * No out-of-range values: safe for app window geometry and alpha animations.
 * Not an actual velocity-driven SpringAnimation.
 */
public final class SpringEase implements TimeInterpolator {
    public static final SpringEase INSTANCE = new SpringEase();
    private static final double OMEGA = 8.3;
    private static final double NORMALIZER =
            1.0 - (1.0 + OMEGA) * Math.exp(-OMEGA);
    private SpringEase() { }

    @Override
    public float getInterpolation(float input) {
        double t = Math.max(0.0, Math.min(1.0, input));
        double response = 1.0 - (1.0 + OMEGA * t) * Math.exp(-OMEGA * t);
        return (float) Math.max(0.0, Math.min(1.0, response / NORMALIZER));
    }
}
