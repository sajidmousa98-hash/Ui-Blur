import math
OMEGA=8.3
N=1-(1+OMEGA)*math.exp(-OMEGA)
def ease(t):
    t=max(0,min(1,t))
    return max(0,min(1,(1-(1+OMEGA*t)*math.exp(-OMEGA*t))/N))
assert abs(ease(0))<1e-6
assert abs(ease(1)-1)<1e-6
values=[ease(i/1000) for i in range(1001)]
assert all(0<=v<=1 for v in values)
assert all(x<=y for x,y in zip(values,values[1:]))
print('Spring response bounded and monotonic: OK')
