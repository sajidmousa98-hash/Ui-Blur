# One UI MotionGlass Lab v0.2 (ALPHA)

**For rooted Samsung One UI Home only.** This is an experimental LSPosed APK source project, NOT a finished universal iOS-motion-blur port. Designed as a cautious starting point for Galaxy S23 / One UI 9 / Android 17, **not tested on that build**.

## Exactly what the source tries to do

1. **Icon motion trail**: On recognized One UI Home app icon `performClick()`, takes one capped-size icon-view snapshot and composites seven semi-transparent copies along a short motion path over ~310 ms. It adds a faint expanding rounded halo. This is a multi-sampled **icon trail** (an approximation of motion blur), **not compositor-level directional blur of the full app window**.
2. **Spring-like interpolation**: In launcher app-transition stack traces only, adjusts eligible `ValueAnimator` durations by 6% and replaces only standard/linear curves with a normalized critically damped spring-like ease. It intentionally skips Samsung custom curves and gesture-driven transitions.
3. **Roundness boost**: In recognized launcher transition stack traces only, slightly increases existing non-zero `SurfaceControl.Transaction.setCornerRadius()` values. It does not create clipping for surfaces that are originally square, and does not implement actual icon-to-app-window surface morphing.
4. **Research logs**: Reports likely Quickstep/One UI Home classes and hooked-method counts in LSPosed logs, prefixed `MotionGlass v0.2:`.

**Not included/guaranteed**: true full-window velocity-dependent blur, universal app-to-app effects, every-app launch route, fully custom remote animation surfaces, all apps' closing blur, 1:1 iPhone animations, or device-proven stability. This is source code with a GitHub Actions build pipeline: no compiled APK is included.

## Build using only your phone and GitHub

The separate distribution archive **`MotionGlass-v0.2-Source.zip`** contains the project tree. Upload it *as a ZIP* (do not extract) to your repository root, and create a new file named `.github/workflows/build.yml` containing **`MotionGlass-v0.2-GitHub-build.yml`** (you can copy/paste the file contents in GitHub's editor). Push/save both files.

Then go to **Actions → Build MotionGlass v0.2 from ZIP → Run workflow**, or let the push trigger it. After it succeeds, open the run's **Artifacts** and download `MotionGlass-v0.2-LSPosed-APK`. Extract the artifact ZIP and install `app-debug.apk`.

If you're a developer, you can instead unzip the project locally and push the extracted project to GitHub. The project also includes an internal `.github/workflows/build.yml` that compiles directly from source; keep only one active workflow.

## LSPosed setup

1. Back up critical data and ensure you can disable LSPosed in safe mode if One UI Home fails to launch.
2. If you previously installed MotionGlass v0.1 built with a different GitHub debug signing key, uninstall v0.1 before installing v0.2. Do not uninstall One UI Home itself.
3. Install `app-debug.apk` as a regular Android app (it has no user-facing activity or launcher icon).
4. In **LSPosed**, enable **MotionGlass Lab v0.2 (Alpha)**, scope **only** `One UI Home / com.sec.android.app.launcher`. Do **not** scope Android System, SystemUI, or all apps.
5. Restart One UI Home by rebooting. Test opening apps from home and closing apps to home. Some transitions might show no change if Samsung's code paths have different names/objects.
6. Look in LSPosed logs for `MotionGlass v0.2:` and share lines showing which classes/hooks were found. Those logs plus the exact One UI Home APK will make further Samsung-specific development possible.

## Recovery

If animations cause glitches, disable the module in LSPosed and reboot. If the launcher crashes and you can't open LSPosed, use your root framework's safe/disable-module recovery method. **Never flash modified SystemUI or launcher APKs** for this test; the module does not replace any system APK.

## Technical design

- Hooks are installed only in the Samsung launcher process, not all Android processes.
- Optional effect filters and duration/radius bounds prioritize stability over coverage.
- The overlay is transient and removed when its animator ends/cancels. It does not request overlay permissions.
- The build-only Xposed API stub package is `compileOnly`; LSPosed supplies the actual Xposed runtime.
- `tests/test_spring.py` validates the spring response is normalized, monotonic and within `[0,1]`.

## What is needed for genuine all-app motion blur?

A specific reverse engineering pass over the device's **One UI Home APK** (package `com.sec.android.app.launcher`) and its remote animation / shell-transition integration, followed by per-frame window-surface render work and device tests. A launcher-only Java hook cannot promise velocity-dependent blur of arbitrary app windows. Samsung firmware version changes may invalidate hook points.

Reference architecture: AOSP Launcher3 `QuickstepTransitionManager` and Android `SurfaceControl.Transaction` remote animation target implementation.
