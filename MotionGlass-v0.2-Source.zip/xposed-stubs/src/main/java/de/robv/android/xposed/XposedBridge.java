package de.robv.android.xposed;

import java.util.Set;

/** Build-only signature. Not packaged in the app APK. */
public final class XposedBridge {
    private XposedBridge() { }
    public static Set<XC_MethodHook.Unhook> hookAllMethods(Class<?> clazz, String methodName, XC_MethodHook hook) {
        throw new UnsupportedOperationException("compile-time stub only");
    }
    public static void log(String text) {
        throw new UnsupportedOperationException("compile-time stub only");
    }
}
